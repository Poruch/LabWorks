﻿#include <iostream>
#include <fstream>
#include <filesystem>
#include <windows.h>

#pragma execution_character_set("utf-8") //Установка кодировки UTF-8 для компилятора

using namespace std;

// Создание структуры элемента списка
struct Elem {
    int value;
    Elem* next;
};

// Функция вставки элемента в голову списка
void InsertAtHead(Elem*& head, int data) {
    Elem* newNode = head;
    head = new Elem;
    head->value = data;
    head->next = newNode;
}

// Функция просмотра элементов списка от головы к хвосту
void BrListFromFirst(Elem* head) {
    while (head != nullptr) {
        cout << head->value << " ";
        head = head->next;
    }
}

// Функция просмотра элементов списка от хвоста к голове (рекурсивно)
void BrListFromEnd(Elem* head) {
    if (head != nullptr) {
        BrListFromEnd(head->next);
        cout << head->value << " ";
    }
}

int main() {

    SetConsoleOutputCP(65001); //Установка кодировки UTF-8 для вывода в консоль

    filesystem::path currentPath = filesystem::current_path(); // Получение текущей директории файлов

    Elem* head = nullptr;
    string fileName;
    int value;

    cout << "Введите имя файла: > ";
    cin >> fileName;

    ifstream file;
    file.open(currentPath.string() + "\\" + fileName, ios::in); //Открытие выбранного файла, расположенного в директории программы

    if (!file.is_open()) {
        cout << "Не удалось открыть файл." << endl;
        return 1;
    }
    else
    {

        cout << "Введенные данные из файла:" << endl;

        while (file >> value) {
            cout << value << " ";
            InsertAtHead(head, value);  //Добавление элемента в голову списка
        }

    file.close();

    cout << endl << "Вывод списка с начала:" << endl;
    BrListFromFirst(head);

    cout << endl << "Вывод списка с конца:" << endl;
    BrListFromEnd(head);

    return 0;

    }

}